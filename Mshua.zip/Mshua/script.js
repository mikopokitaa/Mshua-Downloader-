// Script to update the current year in the footer
        document.getElementById('currentYear').innerText = new Date().getFullYear();

        // Smooth scrolling for navigation links
        document.querySelectorAll('nav ul li a').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                const href = this.getAttribute('href');
                // Check if the href is an internal anchor link (starts with #)
                if (href.startsWith('#')) {
                    e.preventDefault();
                    document.querySelector(href).scrollIntoView({
                        behavior: 'smooth'
                    });
                }
                // If it's an external link (e.g., to another page), let it behave normally
            });
        });

        // Function to launch the app or redirect to download
        function launchApp() {
          const now = new Date().getTime();
          const timeout = 2000; // milliseconds - muda kidogo mrefu zaidi kutoa app nafasi ya kufunguka

          // Kujaribu kufungua app kupitia intent (kwa Android)
          // Hakikisha 'package=mshuadownloader' inalingana na package name ya app yako ya Android
          // Na 'scheme=app' inalingana na scheme ya app yako.
          // Hii ni muhimu sana kwa kufungua app kutoka kwenye kivinjari.
          window.location = 'intent://#Intent;package=mshuadownloader;scheme=app;end;';

          // Kama haijafunguka ndani ya muda wa 'timeout', peleka kwenye link ya MediaFire
          setTimeout(() => {
            const later = new Date().getTime();
            // Hapa tunaangalia kama muda uliochukuliwa tangu 'now' ni mdogo kuliko 'timeout + kiasi kidogo'
            // Hii inamaanisha kivinjari hakikubadilisha URL (app haikufunguka).
            if (later - now < timeout + 500) { // Nimeongeza 500ms kidogo kutoa nafasi zaidi
              window.location.href = 'https://www.mediafire.com/file/vktzh7vuwyqx38b/MshuaDownloader.apk/file';
            }
          }, timeout);
        }
